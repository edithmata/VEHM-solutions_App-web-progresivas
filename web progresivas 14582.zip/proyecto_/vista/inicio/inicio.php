<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyecto PWA <?php echo date("Y"); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="../configuracion/css/login.css">
</head>

<body>
    <!-- INICIA EL MENU PRINCIPAL -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01"
                aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Inicio
                            <span class="visually-hidden">(current)</span>
                        </a>
                    </li>
                </ul>
                <form class="d-flex">
                    <input class="form-control me-sm-2" type="text" placeholder="¿Qué desea encontrar?">
                    <button class="btn btn-secondary my-2 my-sm-0" type="submit">Buscar</button>
                </form>
            </div>
        </div>
    </nav>
    <!-- TERMINA EL MENU PRINCIPAL -->
    <!-- INICIA EL CONTENIDO DE LA PÁGINA -->
   
    <div class="cont-padre">
    <h1 style="margin-bottom: 7%;margin-top:3%; text-align: center">¡Te damos la bienvenida!</h1>
        <div class="row cont-log">
            <div class="col-12 col-xl-6 col-lg-6">
                <div class="cont row">
                    <div class="col-6  img">
                        <img src="configuracion/imagenes/taco.jpeg" class="card-img-top user">
                    </div>
                    
                        <div class=" col-6 card-body">
                            <h5 class="card-title">INICIO DE SESIÓN <br><hr> <i> Usuario</i></h5>
                            <p class="card-text"><button data-bs-toggle="modal" data-bs-target="#modal_login_usuario"
                                    class="btn btn-primary btn-login">Ingresar</button></p>
                        </div>
                    </div>
                </div>
          
            <div class="col-12 col-xl-6 col-lg-6">
                <div class="cont row">
                    <div class="col-6 img">
                    <img src="configuracion/imagenes/mora.jpg" class="card-img-top user" >
                    </div>
                    <div class=" col-6 card-body">
                        <h5 class="card-title">INICIO DE SESIÓN <br>  <hr> <i> Admin</i></h5>
                        <p class="card-text"><button data-bs-toggle="modal" data-bs-target="#modal_login_admin"
                                class="btn btn-primary btn-login">Ingresar</button></p>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- TERMINA EL CONTENIDO DE LA PÁGINA -->

    <!-- INICIA MODAL PARA LOGIN -->
    <div class="modal fade" id="modal_login_usuario">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h3 class="modal-title"><i> <b> ¡Hola Usuario!</b></i> <br>-Inicia sesión-</h3>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="form-group">
                        <label for="user">Usuario:</label>
                        <input type="text" class="form-control" placeholder="Ingrese usuario" id="user">
                    </div>
                    <div class="form-group">
                        <label for="user_pass">Contraseña:</label>
                        <input type="password" class="form-control" placeholder="Ingrese Contraseña" id="user_pass">
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer" style="text-align: center; display: inline;">
                  <button type="button" onclick="login_usuario()" class="btn btn-primary btn-datos">Ingresar</button>
                    <button type="button" class="btn btn-danger btn-datos" data-bs-dismiss="modal">Cerrar</button>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modal_login_admin">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h3 class="modal-title"> <i> <b>¡Hola Administrador!</b> </i> <br>-Inicia sesión-</h3>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="form-group">
                        <label for="user_admin">Usuario:</label>
                        <input type="text" class="form-control" placeholder="Ingrese Usuario" id="user_admin">
                    </div>
                    <div class="form-group">
                        <label for="admin_pass">Contraseña</label>
                        <input type="password" class="form-control" placeholder="Ingrese Contraseña" id="admin_pass">
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer" style="text-align: center; display: inline;">
                    <button type="button" onclick="login_admin()" class="btn btn-primary btn-datos">Ingresar</button>
                    <button type="button" class="btn btn-danger btn-datos" data-bs-dismiss="modal">Cerrar</button>
                </div>

            </div>
        </div>
    </div>
    <!-- TERMINA MODAL PARA LOGIN -->

<div id="show_alert"></div>

<!-- ALERTAS PARA LOGIN -->
<div class="alert alert-success alert-dismissible fade" style="position: fixed; top: 8%; right: 0; z-index: 10000;" id="alerta_login_correcto">
  <p id="texto_bienvenida"></p>
</div>
<div class="alert alert-danger alert-dismissible fade" style="position: fixed; top: 8%; right: 0; z-index: 10000;" id="alerta_login_error">
  <p id="texto_error"></p>
</div>
<!-- FIN DE ALERTAS PARA LOGIN-->






    <!-- SE LLAMA AL ARCHIVO login.js -->
    <script src="configuracion/js/login.js"></script>
    <script src="configuracion/js/login_admin.js"></script>
</body>

</html>